-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Ago 26, 2010 as 11:11 PM
-- Versão do Servidor: 5.0.45
-- Versão do PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `lug`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `dados`
-- 

CREATE TABLE `dados` (
  `id` int(10) NOT NULL auto_increment,
  `nome` varchar(40) NOT NULL,
  `valor` varchar(10) NOT NULL,
  `tipo` varchar(40) NOT NULL,
  `categoria` varchar(40) NOT NULL,
  `Lug_uso` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `dados`
-- 

INSERT INTO `dados` (`id`, `nome`, `valor`, `tipo`, `categoria`, `Lug_uso`) VALUES 
(1, 'ioioio', 'iuuyuy', 'ddfd', 'cvvcvc', 'vvcc'),
(2, 'ioioio', 'iuuyuy', 'ddfd', 'cvvcvc', 'vvcc'),
(3, 'Full Metal Alchemist', '100,10', 'Video', 'Shonen', 'Magic');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `imagem`
-- 

CREATE TABLE `imagem` (
  `id` int(10) NOT NULL auto_increment,
  `id_dados` int(10) NOT NULL,
  `temp` varchar(50) NOT NULL,
  `tamanho` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `imagem`
-- 

INSERT INTO `imagem` (`id`, `id_dados`, `temp`, `tamanho`, `nome`) VALUES 
(1, 1, 'temp/My Logo.png', '532492', 'My Logo.png'),
(2, 2, 'temp/My Logo.png', '532492', 'My Logo.png'),
(3, 3, 'temp/63.gif', '22636', '63.gif');
